#!/usr/bin/env bash
set -euo pipefail

# NAT v13.0 replication scaffold
# Edit these variables for your environment.
FASTQ_DIR="${FASTQ_DIR:-./fastq}"
OUT_DIR="${OUT_DIR:-./out}"
WORKSHEET="${WORKSHEET:-./blinded_worksheet_template_v13.csv}"

mkdir -p "$OUT_DIR"

echo "This is a scaffold. Steps you typically run:"
echo "1) fastqc -o $OUT_DIR/fastqc $FASTQ_DIR/*.fastq.gz"
echo "2) Extract FastQC module statuses/metrics into: $WORKSHEET"
echo "3) Run your NAT scoring/render step (frozen v13.0) to produce:"
echo "   - nat_score_v13, nat_decision_v13"
echo "   - song_render_path (16-bar deterministic snippet)"
echo
echo "Tip: Keep tool versions + commands in a run log for auditability."
