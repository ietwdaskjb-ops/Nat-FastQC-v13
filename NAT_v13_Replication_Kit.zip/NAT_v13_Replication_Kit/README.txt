NAT v13.0 Replication Kit
Date generated: 2026-01-21

Contents
- UTT_NAT_v13_Publication_Ready.pdf
  Publication-ready methods summary for the frozen mapping + blinded validation protocol.
- blinded_worksheet_template_v13.csv
  Worksheet template to record blinded sample IDs, FastQC statuses/metrics, NAT score/decision, audio path, and post-unblind truth labels.
- run_all.sh
  Minimal driver script scaffold (edit paths and tool commands for your environment).
- CHECKSUMS_SHA256.txt
  SHA-256 checksums for all files in this kit.

Workflow (high level)
1) Assemble 30 public samples (GIAB, FDA-ARGOS, Zymo) and assign blinded IDs S01-S30.
2) Run FastQC. Fill FastQC status + numeric summaries in the worksheet.
3) Compute NAT score/decision using frozen v13.0 penalties and render the deterministic 16-bar snippet per sample.
4) Unblind and compute confusion matrix + sensitivity/specificity.
5) Repeatability check: pick 5 samples, re-run 3 times, confirm identical numeric + audio outputs.

Lock rule
Do not change mapping/weights during blinded scoring. Any changes become v13.1 and require full revalidation.
