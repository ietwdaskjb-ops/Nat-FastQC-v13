NATQC Research Starter Pack

Contents:
- Introduction.txt
- Section3_Protocol.txt
- Related_Work.txt
- NATQC_Definition_and_Problem.txt
- Entanglement_Graph.yaml
- Crosswalks/
- Canonical_Records/

This bundle is designed to be email-ready for collaborators or researchers.