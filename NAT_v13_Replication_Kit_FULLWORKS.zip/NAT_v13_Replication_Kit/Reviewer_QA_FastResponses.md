# Reviewer Objection → Fast Response (NAT v13.0)

| Reviewer concern | 1–2 sentence response |
|---|---|
| “This is subjective / musical interpretation.” | NAT v13.0 contains no listener ratings or aesthetic optimization. Audio is a deterministic encoding of FastQC evidence with bounded parameter ranges and one-to-one module→parameter mapping. |
| “You’re double-counting correlated FastQC metrics.” | Isolation is enforced: each module contributes exactly one penalty and drives exactly one audio parameter; no parameter is driven by multiple modules, preventing hidden redundancy. |
| “This leaks labels / you tuned after seeing outcomes.” | The mapping and penalties are frozen before scoring in a blinded protocol. Performance metrics are computed only after unblinding with pre-declared success criteria. |
| “Overfit to GIAB/FDA-ARGOS/Zymo.” | NAT is not learned and has no trained coefficients; it is a fixed mapping. Any change requires a new version (v13.1+) and full revalidation, preventing post-hoc fitting. |
| “Audio can’t be reproduced exactly across machines.” | Determinism is enforced via fixed render settings and a fixed seed derived from sample_id + version string; repeatability checks require identical numeric outputs and audio hashes across reruns. |
| “Corruption could accidentally improve score.” | Monotonicity is a required invariant and tested with known-bad controls (adapter injection, Ns, tail-quality corruption, harsh trimming). Any improvement under degradation is an explicit failure. |
| “Why not just use the FastQC tables?” | The numeric decision remains primary; audio is an additional modality that can speed anomaly spotting and sample comparison while remaining fully auditable and derived from the same evidence. |
| “FastQC modules vary by version.” | The replication kit requires tool version logging and archives FastQC outputs; the blinded protocol and worksheet schema make deviations explicit and reviewable. |
