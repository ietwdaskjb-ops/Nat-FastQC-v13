# NAT v13.0 Replication Kit (UTT / NAT Deterministic QC Sonification)

**Kit date:** 2026-01-21  
**Spec status:** v13.0 frozen mapping (do not edit weights/rules during blind phase)

This package reproduces the full NAT v13.0 pipeline:

**FASTQ → FastQC → (frozen extraction + penalties) NAT score/decision → deterministic 16‑bar audio render → blinded validation → unblinding metrics**

If you are a reviewer: the key claim is **not** “music is truth”. The claim is that NAT is a **deterministic, auditable encoding** of FastQC evidence, validated via a **blinded** protocol with falsification controls.

---

## What’s inside

- `UTT_NAT_v13_Publication_Ready.pdf`  
  Publication-ready methods: frozen mapping, invariants, scoring/decision rule, deterministic audio spec, blinded validation protocol.
- `blinded_worksheet_template_v13.csv`  
  A results worksheet schema for recording per-sample FastQC outcomes, extracted numeric summaries, NAT outputs, and post‑unblind labels.
- `run_all.sh`  
  Minimal driver scaffold. Edit paths/commands for your environment.
- `CHECKSUMS_SHA256.txt`  
  SHA‑256 checksums for integrity verification.
- `README.md` (this file)
- `Reviewer_Defense_Memo_v13.md`
- `Reviewer_QA_FastResponses.md`
- `Cover_Letter_Paragraph.md`
- `Results_Scaffold.md`

---

## Reproduction workflow (reviewer-friendly)

### A) Blind phase (freeze first, then run)
1. **Assemble samples** (recommended: 30 total, 10 each from GIAB, FDA‑ARGOS, Zymo).  
2. **Assign blinded IDs** (`S01…S30`) and keep the key private until unblinding.
3. **Run FastQC** on each FASTQ (or FASTQ pair).
4. **Populate the worksheet** with:
   - module status (PASS/WARN/FAIL)
   - the specified numeric summaries per module
5. **Run NAT v13.0**
   - compute score (0–100) using frozen penalties
   - apply hard overrides per spec
   - render the deterministic 16‑bar audio snippet per sample

**Lock rule:** do not change weights, thresholds, or mapping during the blind phase. Any change is a new version (v13.1+) and requires revalidation.

### B) Falsification / monotonicity controls (required)
Create “known‑bad” transformed copies (adapter injection, tail‑quality corruption, Ns, harsh trimming).  
Expected outcome: **score must worsen** and **audio must degrade directionally** for each controlled corruption.

### C) Unblind + metrics
After blind artifacts are frozen:
- unblind truth labels
- compute confusion matrix
- compute sensitivity/specificity (especially FAIL sensitivity)
- include per‑sample attribution for any errors

### D) Repeatability
Pick 5 samples × 3 runs:
- identical score + decision across runs
- identical audio output (hash match)

---

## Expected deliverables (minimum)
- FastQC reports archived
- completed worksheet CSV (blind + unblinded label column)
- deterministic audio outputs per sample
- confusion matrix + summary metrics
- run log: commands + tool versions + environment

---

## Integrity verification
Validate kit integrity by checking `CHECKSUMS_SHA256.txt` against your extracted files.

---

## Citation
Reference the frozen methods/spec document:
**UTT / NAT v13.0 – Deterministic QC Sonification (Publication‑Ready Methods + Replication Kit)** (included as PDF in this kit).
