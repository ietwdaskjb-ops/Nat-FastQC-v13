# Results Scaffold (NAT v13.0)

Use this file as the manuscript Results section outline. Replace bracketed placeholders with computed values.

## Dataset
- Total samples: [N=30]
- Sources: [GIAB=10], [FDA-ARGOS=10], [Zymo=10]
- Blind IDs: S01–S30
- FastQC version(s): [vX.Y]
- Environment summary: [OS/CPU/Python/FastQC]

## Primary outcomes
### NAT score distribution
- Mean (SD): [..]
- Median (IQR): [..]
- By truth label (PASS/WARN/FAIL): [..]

### Decision performance
Confusion matrix (truth rows × NAT columns):

| Truth \ NAT | PASS | WARN | FAIL |
|---|---:|---:|---:|
| PASS | [ ] | [ ] | [ ] |
| WARN | [ ] | [ ] | [ ] |
| FAIL | [ ] | [ ] | [ ] |

Derived metrics (report with 95% CI if possible):
- Overall agreement: [..]%
- FAIL sensitivity (recall): [..]%
- FAIL specificity: [..]%
- Macro F1 (optional): [..]

### Error attribution
For each misclassification, provide:
- Sample ID: [S..]
- Truth vs NAT: [..]
- Modules responsible (statuses + key numeric summaries): [..]
- Likely cause: [e.g., borderline per-base quality, adapter spike, overrep seq]
- Suggested follow-up (optional): [confirm read trimming, adapter removal, resequencing]

## Determinism / repeatability
5 samples × 3 runs:
- Scores identical across runs: [Yes/No]
- Decisions identical across runs: [Yes/No]
- Audio hashes identical across runs: [Yes/No]
- If any mismatch: record toolchain differences and treat as a reproducibility failure.

## Monotonicity / known-bad controls
For each control type (adapter injection, Ns, tail-quality corruption, harsh trimming):
- Baseline score: [..]
- Corrupted score: [..] (must be ≤ baseline)
- Audio parameter deltas in expected directionality: [Yes/No]
- Any violation: fail invariant and report.

## Qualitative audit (optional, keep brief)
- Example PASS audio characteristics: stable pitch, low noise, minimal clicks
- Example WARN: mild detune/clicks
- Example FAIL: elevated noise floor, repeated alarm motif, strong detune
