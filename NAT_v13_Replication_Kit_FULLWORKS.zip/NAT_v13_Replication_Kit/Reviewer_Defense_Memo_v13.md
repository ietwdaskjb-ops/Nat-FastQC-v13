# Reviewer Defense Memo (UTT / NAT v13.0)

**Subject:** Why NAT v13.0 sonification is an objective, deterministic QC encoding (not subjective “music”)  
**Applies to:** UTT / NAT v13.0 frozen FastQC→score→audio mapping and blinded validation protocol.

## 1) “Sonification is subjective. Why should we trust musical output?”
NAT v13.0 does not use listener preference, aesthetic optimization, or human scoring. The audio is a *deterministic render* of QC evidence produced from a frozen mapping: each musical parameter is a bounded numeric function of a single FastQC module’s status/summary. “Better” and “worse” are defined only by the QC metrics (e.g., higher adapter content increases click density; higher N content increases noise floor), not by taste.

## 2) “How do you prevent leakage or double-dipping?”
NAT enforces **isolation**: each selected FastQC module controls exactly **one** scoring penalty and **one** song parameter. No module drives multiple penalties; no parameter is driven by multiple modules. This blocks redundant weighting and hidden correlation amplification. Validation is blinded; mapping is frozen prior to scoring, preventing post‑hoc tuning against labels.

## 3) “Is this overfit to your datasets?”
NAT v13.0 is not a learned model. There are no fitted coefficients trained on data. The method is a declared, fixed mapping with pre‑registered success criteria evaluated after unblinding. Any modification to weights/rules becomes a new version (v13.1+) requiring revalidation, preventing silent overfitting.

## 4) “How do you ensure determinism and reproducibility?”
Determinism is explicit: identical FastQC outcomes and extracted summaries yield identical score/decision and identical audio render. The audio seed is fixed (hash(sample_id + “v13.0”)), and render settings (tempo, length) are constant. The replication kit includes the worksheet schema, run log requirements, and repeatability tests (5 samples × 3 runs) requiring identical numeric and audio hashes.

## 5) “Could corruption ever accidentally improve the score?”
NAT pre‑specifies **monotonicity** under controlled degradation and requires “known‑bad” controls (adapter injection, tail quality corruption, Ns, harsh trimming). Corruption must never improve the score or decision; the audio must degrade directionally. This functions as a falsification harness: if degradation improves QC, the invariant fails.

## 6) “What scientific value does audio add?”
The primary output remains standard QC (numeric score + PASS/WARN/FAIL). Audio provides an additional, auditable modality of the same evidence that can accelerate anomaly detection and comparative review without altering the underlying metrics. Because the mapping is frozen and parameter‑driven, the sonification itself is testable and inspectable rather than interpretive.

**Conclusion:** NAT v13.0 is a reproducible, falsifiable QC encoding that adds deterministic auditory representation without introducing subjectivity, leakage, or data‑driven fitting.
