NAT v13.0 Replication Kit
Date generated: 2026-01-21

Start here: README.md

This kit includes the frozen v13.0 methods PDF, a worksheet template, a run scaffold, checksums,
and reviewer-facing documents (defense memo, Q&A, results scaffold).
