#!/usr/bin/env bash
set -euo pipefail

# NAT v13.0 replication driver (scaffold)
# Edit the commands/paths below to match your environment.
# Hard rule: do NOT change mapping/weights during blinded scoring.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FASTQ_DIR="${ROOT_DIR}/data/fastq"
FASTQC_OUT="${ROOT_DIR}/fastqc/raw_reports"
NAT_OUT="${ROOT_DIR}/nat"
RESULTS_OUT="${ROOT_DIR}/results"

mkdir -p "${FASTQC_OUT}" "${NAT_OUT}/audio" "${NAT_OUT}/logs" "${RESULTS_OUT}/blind_phase" "${RESULTS_OUT}/unblinded"

echo "[1/5] Tool versions (fill these in for audit):" | tee "${NAT_OUT}/logs/run.log"
echo "FastQC: $(fastqc --version 2>/dev/null || echo 'UNKNOWN (fastqc not on PATH)')" | tee -a "${NAT_OUT}/logs/run.log"
echo "Python: $(python3 --version 2>/dev/null || echo 'UNKNOWN (python3 not on PATH)')" | tee -a "${NAT_OUT}/logs/run.log"
echo "" | tee -a "${NAT_OUT}/logs/run.log"

echo "[2/5] Run FastQC (edit inputs/glob as needed)..." | tee -a "${NAT_OUT}/logs/run.log"
# Example:
# fastqc -o "${FASTQC_OUT}" "${FASTQ_DIR}"/*.fastq.gz
echo "TODO: Run FastQC here" | tee -a "${NAT_OUT}/logs/run.log"

echo "[3/5] Populate worksheet + run NAT scoring + render deterministic audio..." | tee -a "${NAT_OUT}/logs/run.log"
# Example placeholders:
# python3 nat_extract_and_score.py --fastqc "${FASTQC_OUT}" --worksheet "${ROOT_DIR}/blinded_worksheet_template_v13.csv" --out "${NAT_OUT}"
echo "TODO: Run NAT extraction/scoring/audio render here" | tee -a "${NAT_OUT}/logs/run.log"

echo "[4/5] Repeatability check (5 samples × 3 runs)..." | tee -a "${NAT_OUT}/logs/run.log"
echo "TODO: Implement repeatability harness and record hashes" | tee -a "${NAT_OUT}/logs/run.log"

echo "[5/5] Unblind + compute confusion matrix + metrics (after blind phase is frozen)..." | tee -a "${NAT_OUT}/logs/run.log"
echo "TODO: Run unblinding + metrics here" | tee -a "${NAT_OUT}/logs/run.log"

echo "Done (scaffold). Keep logs + tool versions + commands for auditability."
